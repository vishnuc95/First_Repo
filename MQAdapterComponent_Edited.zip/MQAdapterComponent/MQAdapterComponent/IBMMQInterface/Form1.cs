﻿using CustomLibraries.MQAdapter;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IBMMQInterface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int timeout = 1000;
            int characterset = 1;
            int port = 1419;
            string queue_resp = string.Empty;
            // public MQAdapter(string mqManager, string channel, string ipAddress,
            // string putQueue, string getQueue, int timeout, int charSet, int port)
            //QueueData.Text = "myqueue data";
            MQAdapter adapter = new MQAdapter("MqmanagerName",
           "RequestChannelName", "ipaddress","Queue.RequestName",
            "Queue.ResponseName", timeout, characterset, port);
            queue_resp=adapter.GetMQResponseMessage("correlation id");
            QueueData.Text = queue_resp.ToString();

        }
    }
}
